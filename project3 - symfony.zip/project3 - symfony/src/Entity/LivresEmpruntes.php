<?php

namespace App\Entity;

use App\Repository\LivresEmpruntesRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: LivresEmpruntesRepository::class)]
class LivresEmpruntes
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $livre_prete = null;

    #[ORM\Column(length: 255)]
    private ?string $lecteur = null;

    

    #[ORM\Column]
    private ?\DateTimeImmutable $createdAt = null;

    #[ORM\Column]
    private ?\DateTimeImmutable $updatedAt = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLivrePrete(): ?string
    {
        return $this->livre_prete;
    }

    public function setLivrePrete(string $livre_prete): self
    {
        $this->livre_prete = $livre_prete;

        return $this;
    }

    public function getLecteur(): ?string
    {
        return $this->lecteur;
    }

    public function setLecteur(string $lecteur): self
    {
        $this->lecteur = $lecteur;

        return $this;
    }

  

   

    public function getCreatedAt(): ?\DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeImmutable $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeImmutable
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeImmutable $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }
}
