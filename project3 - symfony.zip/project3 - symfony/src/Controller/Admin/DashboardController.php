<?php

namespace App\Controller\Admin;

use App\Entity\Livres;
use App\Entity\Lecteurs;
use App\Entity\LivresEmpruntes;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Controller\Admin\LecteursCrudController;
use EasyCorp\Bundle\EasyAdminBundle\Config\Crud;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Config\Dashboard;
use EasyCorp\Bundle\EasyAdminBundle\Router\AdminUrlGenerator;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractDashboardController;

class DashboardController extends AbstractDashboardController
{
    public function __construct(
         private AdminUrlGenerator $adminUrlGenerator)
    {
        
    }
    #[Route('/admin', name: 'admin')]
    public function index(): Response
    {
        $url=$this->adminUrlGenerator
        ->setController(LecteursCrudController::class)
        ->generateUrl();

       /*  $url=$this->adminUrlGenerator
        ->setController(LivresCrudController::class)
        ->generateUrl();

        $url=$this->adminUrlGenerator
        ->setController(LivresEmpruntesCrudController::class)
        ->generateUrl() ;   
           //return parent::index(); */
           return $this->redirect($url);

      
      
    }

    public function configureDashboard(): Dashboard
    {
        return Dashboard::new()
            ->setTitle('Project3');
    }

    public function configureMenuItems(): iterable
    {
       yield MenuItem::section('Livres');

       yield MenuItem::section('Livres empruntes');

       yield MenuItem::section('Lecteurs');

       yield MenuItem::subMenu('Lecteurs','fas fa-bars')->setSubItems([
                MenuItem::linkToCrud('Add lecteur','fas fa-plus',Lecteurs::class)->setAction(Crud::PAGE_NEW),
                MenuItem::linkToCrud('Show lecteur','fas fa-eye',Lecteurs::class)
       ]);

       yield MenuItem::subMenu('Livres','fas fa-bars')->setSubItems([
        MenuItem::linkToCrud('Add Livres','fas fa-plus',Livres::class)->setAction(Crud::PAGE_NEW),
        MenuItem::linkToCrud('Show Livres','fas fa-eye',Livres::class)
        ]);
        yield MenuItem::subMenu('Livres Empruntes','fas fa-bars')->setSubItems([
            MenuItem::linkToCrud('Add Livres','fas fa-plus',LivresEmpruntes::class)->setAction(Crud::PAGE_NEW),
            MenuItem::linkToCrud('Show Livres','fas fa-eye',LivresEmpruntes::class)
            ]);
        
        // yield MenuItem::linkToCrud('The Label', 'fas fa-list', EntityClass::class);
    }
}
